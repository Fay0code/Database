function MM_Imgs(){
	//use the item method on the all collection to retrieve all element objects for which the name property or ID attribute is set to imglist
	var oImg = document.all.item("imglist");

	if (oImg != null){
	   if (oImg.length != null){
		  for (i = 0; i < oImg.length; i++){
			 AdjustImg(oImg(i),'80','0')
		  }
	   }else{
		   AdjustImg(document.all.imglist,'80','0')
	   }
	}
}
//*************************************************
//AdjustImg('pimg','200','150')
//*************************************************
function AdjustImg(img_obj,w,h){
	window.setTimeout("i=1",10000);
    oWidth=img_obj.width;
	oHeight=img_obj.height;
	oRate=oWidth/oHeight;
	if (w!=0 && w!=0) {
	  nRate=w/h
	  if (nRate>oRate) {
	    if (w<oWidth) {
			img_obj.width=w;
			img_obj.height=w/oRate;
		}
	  } else {
	    if (h<oHeight){
			img_obj.height=h;
			img_obj.width=h*oRate;
		}
	  }
	} else if (w==0) {
	  if (h<oHeight) {
		  img_obj.height=h;
		  img_obj.width=h*oRate;
	  }
	} else if (h==0) {
	  if (w<oWidth) {
		  img_obj.width=w;
		  img_obj.height=w/oRate;
	  }
	}
}